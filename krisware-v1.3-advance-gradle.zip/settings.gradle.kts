rootProject.name = "krisware-advance"
include("krisware-api", "krisware-core", "krisware-launcher", "converter")
