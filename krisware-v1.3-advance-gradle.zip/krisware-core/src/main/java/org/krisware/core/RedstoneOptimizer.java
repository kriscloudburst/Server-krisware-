package org.krisware.core;
public class RedstoneOptimizer {
    public void optimize(){ System.out.println("[Redstone] optimizing... (skeleton)"); }
}
