package org.krisware.core;
public class TimingsManager {
    public void start(){ System.out.println("[Timings] start"); }
    public void stop(){ System.out.println("[Timings] stop"); }
    public String report(){ return "timings-report"; }
}
