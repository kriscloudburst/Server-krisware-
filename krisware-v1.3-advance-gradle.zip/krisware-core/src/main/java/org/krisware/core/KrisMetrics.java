package org.krisware.core;
public class KrisMetrics {
    public void registerPlugin(String id){ System.out.println("[Metrics] register " + id); }
}
