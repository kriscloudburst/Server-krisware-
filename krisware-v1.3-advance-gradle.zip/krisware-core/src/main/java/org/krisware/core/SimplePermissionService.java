package org.krisware.core;
import org.krisware.api.PermissionService;
import java.util.*; import java.nio.file.*; import java.io.*; import com.google.gson.*;
public class SimplePermissionService implements PermissionService {
    private final Map<String,Set<String>> perms = new HashMap<>();
    private final Set<String> ops = new HashSet<>();
    private final Path file;
    public SimplePermissionService(String path){ file=Paths.get(path); load(); }
    private void load(){ try { if (!Files.exists(file)) return; String t=new String(Files.readAllBytes(file)); JsonObject o=new JsonParser().parse(t).getAsJsonObject(); } catch(Exception e){} }
    public boolean hasPermission(String playerUuid,String node){ if (ops.contains(playerUuid)) return true; return perms.getOrDefault(playerUuid,Collections.emptySet()).contains(node); }
    public boolean isOp(String playerUuid){ return ops.contains(playerUuid); }
    public void addOp(String playerUuid){ ops.add(playerUuid); save(); }
    public void removeOp(String playerUuid){ ops.remove(playerUuid); save(); }
    public void save(){ try{ Files.createDirectories(file.getParent()); Files.write(file, new byte[0]); }catch(Exception e){} }
}
