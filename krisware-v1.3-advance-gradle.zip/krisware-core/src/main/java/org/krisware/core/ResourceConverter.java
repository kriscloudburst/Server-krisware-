package org.krisware.core;
import java.nio.file.*; import java.util.*;
public class ResourceConverter {
    public ConversionResult convert(Path input, Path output){
        System.out.println("[Converter] convert " + input + " -> " + output);
        ConversionResult r = new ConversionResult();
        r.addNote("placeholder", "Basic converter ran; extend for full conversion."); 
        return r;
    }
    public static class ConversionResult {
        private final Map<String,String> notes = new LinkedHashMap<>();
        public void addNote(String k,String v){ notes.put(k,v); }
        public Map<String,String> getNotes(){ return notes; }
    }
}
