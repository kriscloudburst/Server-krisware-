package org.krisware.core;
import org.krisware.api.*;
import java.nio.file.*; import java.util.*;
public class Bootstrap {
    public static void main(String[] args) throws Exception {
        System.out.println("KrisWare Core Bootstrap starting..."); 
        Path data = Paths.get(".").toAbsolutePath();
        // init components
        CommandRegistry registry = new CommandRegistry();
        SimplePermissionService perm = new SimplePermissionService(data.resolve("data/permissions.json").toString());
        registry.setPermissionService(perm);
        // register sample commands
        registry.register(new CommandMeta("help","/help","Show commands",null,false));
        registry.register(new CommandMeta("plugin","/plugin list","List plugins","krisware.admin.plugin",true));
        // init managers (skeletons)
        TimingsManager timings = new TimingsManager();
        KrisMetrics metrics = new KrisMetrics();
        ResourceConverter converter = new ResourceConverter();
        RedstoneOptimizer redstone = new RedstoneOptimizer();
        System.out.println("KrisWare initialized. Use server loop or plugin loader to continue."); 
        // simple loop to keep process alive for demo
        Thread.currentThread().join();
    }
}
