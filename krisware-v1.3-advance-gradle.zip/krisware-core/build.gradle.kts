plugins { java }
dependencies { implementation(project(":krisware-api")); implementation("com.google.code.gson:gson:2.10.1") }
