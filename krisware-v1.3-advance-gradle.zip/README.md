KrisWare v1.3 Advance - Gradle Project Skeleton
==============================================
This archive contains the full project **source skeleton** for KrisWare v1.3 Advance.
It includes modules:
 - krisware-api : plugin & server APIs, command registry, permissions interfaces
 - krisware-core: server core, AI managers, redstone optimizer, metrics
 - krisware-launcher: minimal launcher that starts the core
 - converter: resource-pack converter module

This is source only (no compiled production JAR). To build in Codespaces:
1) Install Java 21
2) ./gradlew clean :krisware-launcher:shadowJar
3) The resulting fat-jar will be in krisware-launcher/build/libs/

Notes:
- Many advanced features are provided as working skeletons and utilities. Implementations can be extended.
- Do NOT run as-is in production without reviewing configs & permissions.
