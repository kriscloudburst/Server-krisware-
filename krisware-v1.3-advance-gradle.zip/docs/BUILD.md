Build instructions (Codespaces or Linux):
1) Install Java 21
sudo apt update && sudo apt install -y openjdk-21-jdk unzip curl git
2) From project root:
./gradlew clean :krisware-launcher:shadowJar
3) The fat jar will be at krisware-launcher/build/libs/krisware.jar
4) Run:
java -Xms2G -Xmx8G -jar krisware-launcher/build/libs/krisware.jar nogui
