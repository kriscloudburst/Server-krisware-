package org.krisware.launcher;
import org.krisware.core.Bootstrap;
public class Launcher {
    public static void main(String[] args) throws Exception {
        System.out.println("KrisWare Launcher starting..."); 
        Bootstrap.main(args);
    }
}
