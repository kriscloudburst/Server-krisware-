plugins { application; id("com.github.johnrengelman.shadow") version "8.1.1" }
application { mainClass.set("org.krisware.launcher.Launcher") }
dependencies { implementation(project(":krisware-core")) }
tasks.withType<com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar> { archiveBaseName.set("krisware"); archiveClassifier.set(""); archiveVersion.set("") }
