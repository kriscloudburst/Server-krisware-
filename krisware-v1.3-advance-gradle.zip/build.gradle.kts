plugins { java }
allprojects {
  repositories { mavenCentral() }
  java { toolchain { languageVersion.set(JavaLanguageVersion.of(21)) } }
}
dependencies { }
