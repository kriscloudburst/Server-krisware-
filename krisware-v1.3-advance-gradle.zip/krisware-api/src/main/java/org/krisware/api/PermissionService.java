package org.krisware.api;
public interface PermissionService {
    boolean hasPermission(String playerUuid, String node);
    boolean isOp(String playerUuid);
    void addOp(String playerUuid);
    void removeOp(String playerUuid);
    void save();
}
