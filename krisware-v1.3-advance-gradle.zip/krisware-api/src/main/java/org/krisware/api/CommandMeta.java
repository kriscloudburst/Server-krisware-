package org.krisware.api;
public class CommandMeta {
    private final String name;
    private final String usage;
    private final String description;
    private final String permission;
    private final boolean adminOnly;
    public CommandMeta(String name, String usage, String description, String permission, boolean adminOnly) {
        this.name=name; this.usage=usage; this.description=description; this.permission=permission; this.adminOnly=adminOnly;
    }
    public String getName(){return name;}
    public String getUsage(){return usage;}
    public String getDescription(){return description;}
    public String getPermission(){return permission;}
    public boolean isAdminOnly(){return adminOnly;}
}
