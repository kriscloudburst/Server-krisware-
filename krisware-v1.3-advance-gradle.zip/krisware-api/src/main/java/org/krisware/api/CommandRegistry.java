package org.krisware.api;
import java.util.*;
public class CommandRegistry {
    private final List<CommandMeta> commands = new ArrayList<>();
    public void register(CommandMeta meta){ commands.add(meta); }
    public List<CommandMeta> getAll(){ return Collections.unmodifiableList(commands); }
    // permission service pluggable
    private PermissionService perm;
    public void setPermissionService(PermissionService p){ this.perm=p; }
    public PermissionService getPermissionService(){ return perm; }
}
