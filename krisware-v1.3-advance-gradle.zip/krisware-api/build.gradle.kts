plugins { `java-library` }
java { withSourcesJar() }
dependencies { api(project(":krisware-core")) }
