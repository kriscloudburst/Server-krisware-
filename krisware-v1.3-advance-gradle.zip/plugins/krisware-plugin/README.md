Place your KrisWare plugin jars here.
