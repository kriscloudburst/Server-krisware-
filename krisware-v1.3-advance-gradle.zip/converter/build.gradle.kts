plugins { application; id('com.github.johnrengelman.shadow') version '8.1.1' }
application { mainClass.set('org.krisware.converter.Main') }
repositories { mavenCentral() }
dependencies { implementation('com.google.code.gson:gson:2.10.1') }
tasks.withType<com.github.jengelman.gradle.plugins.shadow.tasks.ShadowJar> { archiveBaseName.set('krisconverter'); archiveClassifier.set(''); archiveVersion.set('') }
